import React, { useState, useEffect } from 'react';
import ReactQuill from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import './Editor2.css';

const TextEditor2 = ({ subtitles }) => {
  const [editorContent, setEditorContent] = useState('');

  useEffect(() => {
    if (subtitles) {
      setEditorContent(subtitles);
    }
  }, [subtitles]);

  const handleSubtitleUpload = (event) => {
    const file = event.target.files[0];
    const reader = new FileReader();
    reader.onload = (e) => {
      const text = e.target.result;
      setEditorContent(text);
    };
    reader.readAsText(file);
  };

  const formatTime = (srtTimestamp) => {
    const [hours, minutes, secondsAndMilliseconds] = srtTimestamp.split(':');
    const [seconds, milliseconds] = secondsAndMilliseconds.split(',');
    return `${hours}:${minutes}:${seconds}.${milliseconds}`;
  };

  const convertSRTToVTT = (srtContent) => {
    const srtLines = srtContent.split('\n');
    const vttLines = ['WEBVTT', ''];

    srtLines.forEach(line => {
      if (line.match(/(\d{2}:\d{2}:\d{2},\d{3}) --> (\d{2}:\d{2}:\d{2},\d{3})/)) {
        const [start, end] = line.split(' --> ');
        vttLines.push(`${formatTime(start)} --> ${formatTime(end)}`);
      } else {
        vttLines.push(line);
      }
    });

    return vttLines.join('\n');
  };

  const handleMerge = () => {
    const srtContent = editorContent;
    const vttContent = convertSRTToVTT(srtContent);
    const vttBlob = new Blob([vttContent], { type: 'text/vtt' });
    const vttUrl = URL.createObjectURL(vttBlob);
    console.log('Generated VTT URL:', vttUrl);
  };

  return (
    <div className="text-editor">
      <div className="editor-container">
        <input type="file" id="subtitle-file" accept=".srt" onChange={handleSubtitleUpload} className="file-input" />
        <div className="editor-wrapper">
          <ReactQuill
            value={editorContent}
            onChange={setEditorContent}
            placeholder="Edit subtitles here"
            modules={{
              toolbar: [
                [{ 'header': '1'}, {'header': '2'}, { 'font': [] }],
                [{size: []}],
                ['bold', 'italic', 'underline', 'strike', 'blockquote'],
                [{'list': 'ordered'}, {'list': 'bullet'}, {'indent': '-1'}, {'indent': '+1'}],
                ['link', 'image', 'video'],
                ['clean']
              ],
            }}
            formats={[
              'header', 'font', 'size',
              'bold', 'italic', 'underline', 'strike', 'blockquote',
              'list', 'bullet', 'indent',
              'link', 'image', 'video'
            ]}
          />
        </div>
        <button className="submit-button">Submit</button>
        {/* <button onClick={handleMerge} className="merge-button">Merge</button> */}
      </div>
    </div>
  );
};

export default TextEditor2;
