# import User from "../models/UserModel.js"
# import argon2 from "argon2";

# export const getUsers = async(req, res) =>{
#     try {
#         const response = await User.findAll({
#             attributes:['uuid','name','email','role']
#         });
#         res.status(200).json(response);
#     } catch (error) {
#         res.status(500).json({msg: error.message});
#     }

# }

# export const getUserById = async(req, res) =>{
#     try {
#         const response = await User.findOne({
#             attributes:['uuid','name','email','role'],
#             where: {
#                 uuid: req.params.id
#             }
#         });
#         res.status(200).json(response);
#     } catch (error) {
#         res.status(500).json({msg: error.message});
#     }
    
# }

# export const createUser = async(req, res) =>{
#     const {name, email, password, confPassword, role} = req.body;
#     if(password !== confPassword) return res.status(400).json({msg: "Password and Confirm Password do not match"});
#     const hashPassword = await argon2.hash(password);
#     try {
#         await User.create({
#             name: name,
#             email: email,
#             password: hashPassword,
#             role: role
#         });
#         res.status(201).json({msg: "Register Successful"});
#     } catch (error) {
#         res.status(400).json({msg: error.message});
#     }
# }

# export const updateUser = async(req, res) =>{
#     const user = await User.findOne({
#         where: {
#             uuid: req.params.id
#         }
#     });
#     if(!user) return res.status(404).json({msg: "User not found"});
#     const {name, email, password, confPassword, role} = req.body;
#     let hashPassword;
#     if(password == "" || password === null){
#         hashPassword = user.password
#     }else{
#         hashPassword = await argon2.hash(password);
#     }
#     if(password !== confPassword) return res.status(400).json({msg: "Password and Confirm Password do not match"});
#     try {
#         await User.update({
#             name: name,
#             email: email,
#             password: hashPassword,
#             role: role
#         },{
#             where:{
#                 id: user.id
#             }
#         });
#         res.status(200).json({msg: "User Updated"});
#     } catch (error) {
#         res.status(400).json({msg: error.message});
#     }
# }

# export const deleteUser = async(req, res) =>{
#     const user = await User.findOne({
#         where: {
#             uuid: req.params.id
#         }
#     });
#     if(!user) return res.status(404).json({msg: "User not found"});
#     try {
#         await User.destroy({
#             where:{
#                 id: user.id
#             }
#         });
#         res.status(200).json({msg: "User Deleted"});
#     } catch (error) {
#         res.status(400).json({msg: error.message});
#     }
    
# }



from flask import request, jsonify
from models.user import User
from database import db
from argon2 import PasswordHasher

ph = PasswordHasher()

def get_users():
    try:
        users = User.query.with_entities(User.uuid, User.name, User.email, User.role).all()
        return jsonify([user._asdict() for user in users]), 200
    except Exception as e:
        return jsonify({'msg': str(e)}), 500

def get_user_by_id(id):
    try:
        user = User.query.with_entities(User.uuid, User.name, User.email, User.role).filter_by(uuid=id).first()
        if not user:
            return jsonify({'msg': 'User not found'}), 404
        return jsonify(user._asdict()), 200
    except Exception as e:
        return jsonify({'msg': str(e)}), 500

def create_user():
    data = request.get_json()
    if data['password'] != data['confPassword']:
        return jsonify({'msg': 'Password and Confirm Password do not match'}), 400
    
    hashed_password = ph.hash(data['password'])
    
    new_user = User(
        uuid=str(uuid.uuid4()),
        name=data['name'],
        email=data['email'],
        password=hashed_password,
        role=data['role']
    )
    
    try:
        db.session.add(new_user)
        db.session.commit()
        return jsonify({'msg': 'Register Successful'}), 201
    except Exception as e:
        return jsonify({'msg': str(e)}), 400

def update_user(id):
    user = User.query.filter_by(uuid=id).first()
    if not user:
        return jsonify({'msg': 'User not found'}), 404
    
    data = request.get_json()
    if data['password'] and data['password'] != data['confPassword']:
        return jsonify({'msg': 'Password and Confirm Password do not match'}), 400
    
    hashed_password = user.password
    if data['password']:
        hashed_password = ph.hash(data['password'])
    
    try:
        user.name = data['name']
        user.email = data['email']
        user.password = hashed_password
        user.role = data['role']
        
        db.session.commit()
        return jsonify({'msg': 'User Updated'}), 200
    except Exception as e:
        return jsonify({'msg': str(e)}), 400

def delete_user(id):
    user = User.query.filter_by(uuid=id).first()
    if not user:
        return jsonify({'msg': 'User not found'}), 404
    
    try:
        db.session.delete(user)
        db.session.commit()
        return jsonify({'msg': 'User Deleted'}), 200
    except Exception as e:
        return jsonify({'msg': str(e)}), 400
