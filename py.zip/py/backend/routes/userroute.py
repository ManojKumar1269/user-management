# import express from "express";
# import {
#     getUsers,
#     getUserById,
#     createUser,
#     updateUser,
#     deleteUser
# } from "../controllers/Users.js";
# import { verifyUser, adminOnly } from "../middleware/AuthUser.js";

# const router = express.Router();

# router.get('/users', verifyUser, adminOnly, getUsers);
# router.get('/users/:id', verifyUser, adminOnly, getUserById);
# router.post('/users', verifyUser, adminOnly, createUser);
# router.patch('/users/:id', verifyUser, adminOnly, updateUser);
# router.delete('/users/:id', verifyUser, adminOnly, deleteUser);

# // router.get('/users', getUsers);
# // router.get('/users/:id', getUserById);
# // router.post('/users', createUser);
# // router.patch('/users/:id', updateUser);
# // router.delete('/users/:id', deleteUser);

# export default router;

from flask import Blueprint
from controllers.user import get_users, get_user_by_id, create_user, update_user, delete_user
from middleware.authuser import verify_user, admin_only

user_bp = Blueprint('user_bp', __name__)

user_bp.route('/users', methods=['GET'])(verify_user(admin_only(get_users)))
user_bp.route('/users/<user_id>', methods=['GET'])(verify_user(admin_only(get_user_by_id)))
user_bp.route('/users', methods=['POST'])(verify_user(admin_only(create_user)))
user_bp.route('/users/<user_id>', methods=['PATCH'])(verify_user(admin_only(update_user)))
user_bp.route('/users/<user_id>', methods=['DELETE'])(verify_user(admin_only(delete_user)))
