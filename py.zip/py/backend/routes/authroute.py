# import express from "express";
# import {Login, logOut, Me} from "../controllers/Auth.js";

# const router = express.Router();

# router.get('/me', Me);
# router.post('/login', Login);
# router.delete('/logout', logOut);

# export default router;

from flask import Blueprint
from controllers.auth import login, logout, me

auth_bp = Blueprint('auth_bp', __name__)

auth_bp.route('/me', methods=['GET'])(me)
auth_bp.route('/login', methods=['POST'])(login)
auth_bp.route('/logout', methods=['DELETE'])(logout)
