# import express from "express";
# import cors from "cors";
# import session from "express-session";
# import dotenv from "dotenv";
# import db from "./config/Database.js";
# import UserRoute from "./routes/UserRoute.js";
# import AuthRoute from "./routes/AuthRoute.js";
# import SequelizeStore from "connect-session-sequelize";

# dotenv.config();

# const app = express();

# const sessionStore = SequelizeStore(session.Store);

# const store = new sessionStore({
#     db: db
# });

# // (async()=>{
# //     await db.sync();
# // })();

# app.use(session({
#     secret: process.env.SESS_SECRET,
#     resave: false,
#     saveUninitialized: true,
#     cookie: {
#         secure: 'auto'
#     }
# }));

# app.use(cors({
#     credentials: true,
#     origin: 'http://localhost:3000'
# }));
# app.use(express.json());
# app.use(UserRoute);
# app.use(AuthRoute);


# // store.sync();

# app.listen(process.env.APP_PORT, ()=> {
#     console.log('Server up and running...');
# });


from flask import Flask
from flask_cors import CORS
from flask_session import Session
from dotenv import load_dotenv
import os
from database import db, mongo
from routes.user import user_bp
from routes.auth import auth_bp

# Load environment variables
load_dotenv()

app = Flask(__name__)

# Configuration
app.config['MONGO_URI'] = os.getenv('DATABASE_URL') or 'mongodb://localhost:27017/atomic_db'
app.config['SECRET_KEY'] = os.getenv('SECRET_KEY') or 'your_secret_key'
app.config['SESSION_TYPE'] = 'filesystem'
app.config['SESSION_PERMANENT'] = False
app.config['SESSION_USE_SIGNER'] = True
app.config['SESSION_KEY_PREFIX'] = 'session:'
app.config['SESSION_COOKIE_NAME'] = 'session'
app.config['SESSION_COOKIE_SECURE'] = 'auto'

# Initialize extensions
mongo.init_app(app)
Session(app)
CORS(app, supports_credentials=True, origins=['http://localhost:3000'])

# Register blueprints
app.register_blueprint(user_bp, url_prefix='/api')
app.register_blueprint(auth_bp, url_prefix='/auth')

if __name__ == '__main__':
    app.run(port=int(os.getenv('APP_PORT', 5000)), debug=True)
