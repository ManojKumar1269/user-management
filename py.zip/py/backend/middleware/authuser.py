# import User from "../models/UserModel.js";

# export const verifyUser = async (req, res, next) =>{
#     if(!req.session.userId){
#         return res.status(401).json({msg: "login to your account!"});
#     }
#     const user = await User.findOne({
#         where: {
#             uuid: req.session.userId
#         }
#     });
#     if(!user) return res.status(404).json({msg: "User not found"});
#     req.userId = user.id;
#     req.role = user.role;
#     next();
# }

# export const adminOnly = async (req, res, next) =>{
#     const user = await User.findOne({
#         where: {
#             uuid: req.session.userId
#         }
#     });
#     if(!user) return res.status(404).json({msg: "User not found"});
#     if(user.role !== "admin") return res.status(403).json({msg: "Access prohibited"});
#     next();
# }


from flask import request, jsonify, session
from models.user import User

def verify_user(f):
    def wrap(*args, **kwargs):
        if 'userId' not in session:
            return jsonify({'msg': 'Login to your account!'}), 401
        
        user = User.query.filter_by(uuid=session['userId']).first()
        if not user:
            return jsonify({'msg': 'User not found'}), 404
        
        request.user_id = user.id
        request.role = user.role
        return f(*args, **kwargs)
    return wrap

def admin_only(f):
    def wrap(*args, **kwargs):
        user = User.query.filter_by(uuid=session['userId']).first()
        if not user:
            return jsonify({'msg': 'User not found'}), 404
        if user.role != 'admin':
            return jsonify({'msg': 'Access prohibited'}), 403
        return f(*args, **kwargs)
    return wrap
