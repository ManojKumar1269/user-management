import React, { useState } from 'react';
import axios from 'axios';
import './Editor1.css';

const TextInputForm = ({ onTransfer }) => {
    const [searchKeyword, setSearchKeyword] = useState('');
    const [customPrompt, setCustomPrompt] = useState('');
    const [articles, setArticles] = useState([]);
    const [error, setError] = useState('');

    const handleSearchKeywordChange = (e) => {
        setSearchKeyword(e.target.value);
    };

    const handleCustomPromptChange = (e) => {
        setCustomPrompt(e.target.value);
    };

    const handleSubmit = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:3000/api/scrape', { keyword: searchKeyword });
            setArticles(response.data.articles);
        } catch (error) {
            setError('Failed to fetch articles. Please try again.');
            console.error(error);
        }
    };

    return (
        <div className="text-input-form">
            <div className="card">
                <form onSubmit={handleSubmit}>
                    <div>
                        <label>Enter your search keyword:</label>
                        <input 
                            type="text" 
                            value={searchKeyword} 
                            onChange={handleSearchKeywordChange} 
                            placeholder="Enter your search keyword" 
                        />
                    </div>
                    <div>
                        <label>Enter the custom prompt for the chat model:</label>
                        <textarea 
                            value={customPrompt} 
                            onChange={handleCustomPromptChange} 
                            placeholder="Enter the custom prompt for the chat model" 
                        />
                    </div>
                    <button type="submit">Scrape Blogs and Generate Insights</button>
                </form>
            </div>
            {error && <div className="error">{error}</div>}
            <div className="card">
                <h2>Scraped Articles</h2>
                {articles.length > 0 ? (
                    <ul>
                        {articles.map((article, index) => (
                            <li key={index}>
                                <a href={article.link} target="_blank" rel="noopener noreferrer">{article.title}</a>
                            </li>
                        ))}
                    </ul>
                ) : (
                    <p>No articles found</p>
                )}
            </div>
        </div>
    );
};

export default TextInputForm;
