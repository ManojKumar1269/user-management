import React, { useState } from 'react';
import Layout from './Layout';
import TextInputForm from '../components/Editor';
import Editor2 from '../components/Editor2';
//import axios from 'axios';

const Products = () => {



  return (
    <Layout>
      <div>
        <TextInputForm/>
      </div>
      {/* <div>
        <Editor2/>
      </div> */}
    </Layout>
  );
};

export default Products;
